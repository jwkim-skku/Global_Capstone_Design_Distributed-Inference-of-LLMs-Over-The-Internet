"""
Petals package for distributed inference.
"""


"""
Mini Petals - Distributed Inference System
"""
__version__ = "0.1.0"

